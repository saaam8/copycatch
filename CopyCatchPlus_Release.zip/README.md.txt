# CopyCatch+ – Smart Clipboard with Cleaning

Tracks all copied text and gives you the option to copy a cleaned version.

